﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sanitize e Validate</title>
	
</head>
<body>
	<?php
	$cidade=$_POST["cidade"];
	$sCidade=filter_input(INPUT_POST, "cidade", FILTER_SANITIZE_SPECIAL_CHARS);
	echo "Cidade sem sanitize: $cidade";
	echo "<br> Cidade com sanitize: $sCidade";
	echo "<br> <br> ";

	$idade=$_POST["idade"];
	$sIdade=filter_input(INPUT_POST, "idade", FILTER_SANITIZE_NUMBER_INT);
	echo "Idade sem sanitize: $idade";
	echo "<br> Idade com sanitize: $sIdade";
	if(!filter_var($sIdade, FILTER_VALIDATE_INT))
	echo " A idade precisa ser inteira";
	echo "<br> <br> ";

	$valor=$_POST["valor"];
	$sValor=filter_input(INPUT_POST, "valor", FILTER_SANITIZE_NUMBER_FLOAT);
	echo "Valor sem sanitize: $valor";
	echo "<br> Valor com sanitize: $sValor";
	echo "<br> <br> ";

	$email=$_POST["email"];
	$sEmail=filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
	echo "Email sem sanitize: $email";
	echo "<br> Email com sanitize: $sEmail";
	echo "<br> <br> ";

	$url=$_POST["url"];
	$sUrl=filter_input(INPUT_POST, "url", FILTER_SANITIZE_URL);
	echo "Url sem sanitize: $url";
	echo "<br> Url com sanitize: $sUrl";
	echo "<br> <br> ";



	
    ?>
	
</body>
</html>
