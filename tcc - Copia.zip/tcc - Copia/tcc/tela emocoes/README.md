# Responsive News Card Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/geraldo-molusco/pen/mdabBem](https://codepen.io/geraldo-molusco/pen/mdabBem).

I builth another Card Slider for news and blog pages etc with swiper.js. I made sweet animations when mouse hover and slide changes. Also all of them responsive.