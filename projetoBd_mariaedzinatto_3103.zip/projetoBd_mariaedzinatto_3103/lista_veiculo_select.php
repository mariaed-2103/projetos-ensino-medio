<?php

function lista_vei_select(){

/*1- realizando a conexao com o banco de dados (local, usuario,senha,nomeBanco)*/
     //$con=mysqli_connect("localhost","root","","bd_projeto");  

     require "conexao.php";

     /*2- criando o comando sql para consulta dos registros */
     $comandoSql= "select id_veiculo, nome from tb_veiculo";

     /*3- executando o comando sql */
     $resultado=mysqli_query($con,$comandoSql);
     
     echo "<select name='veiculo' class='form-control'>";

     /*4- pegando os dados da consulta criada e exibindo */
     while($dados=mysqli_fetch_assoc($resultado)){
       $id_veiculo= $dados["id_veiculo"];
       $nome=$dados["nome"];


       echo "<option value=$id_veiculo> $nome </option>";
	   
     }//fim do while

     echo"</select>";

    }//fim da função lista_vei_select()

    //lista_vei_select();




    function lista_vei_select_id($cliente){

        /*1- realizando a conexao com o banco de dados (local, usuario,senha,nomeBanco)*/
             //$con=mysqli_connect("localhost","root","","bd_projeto");  
        
             require "conexao.php";
        
             /*2- criando o comando sql para consulta dos registros */
             $comandoSql= "select id_veiculo, nome from tb_veiculo";
        
             /*3- executando o comando sql */
             $resultado=mysqli_query($con,$comandoSql);
             
             echo "<select name='veiculo' class='form-control'>";
        
             /*4- pegando os dados da consulta criada e exibindo */
             while($dados=mysqli_fetch_assoc($resultado)){
               $id_veiculo= $dados["id_veiculo"];
               $nome=$dados["nome"];
        
        
               if($id_veiculo==$cliente)
               echo "<option value=$id_veiculo selected> $nome </option>";
               else
               echo "<option value=$id_veiculo> $nome </option>";
               
             }//fim do while
        
             echo"</select>";
        
            }

            //lista_vei_select_id(2);


?>