
package mini_tcc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    
//método de criação da conexao
    
    private String url =
            "jdbc:mysql://localhost/bdboutique?useTimezone=true"
            + "&serverTimezone=UTC";
    private String usuario = "root";
    private String senha ="";
    
    public Connection conectar(){
        try{
            
            //caminho para Driver de conexao
            
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            
            //instanciar a conexao
            
            Connection conexao = DriverManager.getConnection(url,usuario,senha);
            return conexao;
            }catch(SQLException sqle){
                System.out.println("SQLException:" + sqle.getMessage());
                return null;
            }catch(Exception e){
                System.out.println("Exception:"+e.getMessage());
                return null;
            }
    }
    
}
