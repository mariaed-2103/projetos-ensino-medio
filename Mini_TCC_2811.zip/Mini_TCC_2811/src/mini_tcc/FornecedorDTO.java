
package mini_tcc;

public class FornecedorDTO {
    
    private int id_fornec;
    private String telefone_fornec;
    private String email_fornec;
    private String endereco_fornec;
    private String cnpj_fornec;
    private String produtofornecido;
    private String nome_fornec;

    public String getProdutofornecido() {
        return produtofornecido;
    }

    public void setProdutofornecido(String produtofornecido) {
        this.produtofornecido = produtofornecido;
    }

    public String getNome_fornec() {
        return nome_fornec;
    }

    public void setNome_fornec(String nome_fornec) {
        this.nome_fornec = nome_fornec;
    }
    
    public int getId_fornec() {
        return id_fornec;
    }

    public void setId_fornec(int id_fornec) {
        this.id_fornec = id_fornec;
    }

    public String getTelefone_fornec() {
        return telefone_fornec;
    }

    public void setTelefone_fornec(String telefone_fornec) {
        this.telefone_fornec = telefone_fornec;
    }

    public String getEmail_fornec() {
        return email_fornec;
    }

    public void setEmail_fornec(String email_fornec) {
        this.email_fornec = email_fornec;
    }

    public String getEndereco_fornec() {
        return endereco_fornec;
    }

    public void setEndereco_fornec(String endereco_fornec) {
        this.endereco_fornec = endereco_fornec;
    }

    public String getCnpj_fornec() {
        return cnpj_fornec;
    }

    public void setCnpj_fornec(String cnpj_fornec) {
        this.cnpj_fornec = cnpj_fornec;
    }

    
    
}
