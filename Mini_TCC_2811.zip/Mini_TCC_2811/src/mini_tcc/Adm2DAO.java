
package mini_tcc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.Vector;

public class Adm2DAO {
    
     Conexao conexao = new Conexao();
    public boolean cadastrar(Adm2DTO adm){
        String sql="Insert into tbadm(id_adm,nome_adm,telefone_adm,email_adm,cargo,datanasc_adm)values (null,?,?,?,?,?)";
        try{
            PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
            psmt.setString(1,adm.getNome_adm());
            psmt.setString(2,adm.getTelefone_adm());
            psmt.setString(3,adm.getEmail_adm());
            psmt.setString(4,adm.getCargo());
            psmt.setString(5,adm.getDatanasc_adm());
          
            //executeUpdate-criaÃ§Ã£o,atualizacao e delete
            psmt.executeUpdate();
            return true;
          }catch(SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:"+ ex);
              return false;
          }
    }
    
    public Adm2DTO Pesquisar(int id){
        Adm2DTO adm = new Adm2DTO();
        String sql = "Select id_adm, nome_adm, telefone_adm, email_adm, cargo, datanasc_adm from tbadm where id_adm=?";
        try{
            PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
        psmt.setInt(1, id);
        ResultSet rs = psmt.executeQuery();
        rs.next();
        adm.setId_adm(rs.getInt("id_adm"));
        adm.setNome_adm(rs.getString("nome_adm"));
        adm.setTelefone_adm(rs.getString("telefone_adm"));
        adm.setEmail_adm(rs.getString("email_adm"));
        adm.setCargo(rs.getString("cargo"));
        adm.setDatanasc_adm(rs.getString("datanasc_adm"));
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Ocorreu um erro: "+e);
        }
        return adm;
    }
    
    public boolean editar(Adm2DTO adm){
        String sql="Update tbadm set nome_adm=?, telefone_adm=?, email_adm=?, cargo=?, datanasc_adm=? where id_adm=?";
        
        try{
            PreparedStatement psmt=conexao.conectar().prepareStatement(sql);
            psmt.setString(1, adm.getNome_adm());
            psmt.setString(2, adm.getTelefone_adm());
            psmt.setString(3, adm.getEmail_adm());
            psmt.setString(4, adm.getCargo());
            psmt.setString(5, adm.getDatanasc_adm());
            psmt.setInt(6, adm.getId_adm());
            psmt.executeUpdate(); //executeUpdate - criaÃ§Ã£o, atualizaÃ§Ã£o e delete.
            return true;
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Ocorreu um erro."+ex);
            return false;
        }
    }
    
    public boolean excluir(int id){
        String sql="Delete from tbadm where id_adm=?";
        try{
            PreparedStatement psmt=conexao.conectar().prepareStatement(sql);
            psmt.setInt(1, id);
            psmt.executeUpdate(); //executeUpdate - criaÃ§Ã£o, atualizaÃ§Ã£o e delete.
            return true;
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Ocorreu um erro."+ex);
            return false;
        }
    }
    
    public Vector Listar(){
          Vector lista = new Vector();
          try{
              String SQL = "Select id_adm, nome_adm, telefone_adm, email_adm from tbadm";
              PreparedStatement psmt = conexao.conectar().prepareStatement(SQL);
              ResultSet rs = psmt.executeQuery();
              
              while(rs.next()){
                  Adm2DTO adm = new Adm2DTO();
                  adm.setId_adm(rs.getInt("id_adm"));
                  adm.setNome_adm(rs.getString("nome_adm"));
                  adm.setTelefone_adm(rs.getString("telefone_adm"));
                  adm.setEmail_adm(rs.getString("email_adm"));
                  
                  
                  //*irá armazenar o cargo dentro do vetor*/
                  Vector Vadm = new Vector();
                  Vadm.addElement(adm.getId_adm());
                  Vadm.addElement(adm.getNome_adm());
                  Vadm.addElement(adm.getTelefone_adm());
                  Vadm.addElement(adm.getEmail_adm());
                  
                  /*Adicionar o vetor de cargos ao vetor principal */
                  lista.addElement(Vadm);
              }
              return lista;
          }catch(SQLException erro){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro ao listar:" +erro);
              return lista;
          }
      }
     public Vector Listar(String Cargo){
          Vector lista = new Vector();
          try{
              String SQL = "Select id_adm, nome_adm, telefone_adm, email_adm from tbadm where cargo=?";
              PreparedStatement psmt = conexao.conectar().prepareStatement(SQL);
              psmt.setString(1,Cargo);
              ResultSet rs = psmt.executeQuery();
              
              while(rs.next()){
                  Adm2DTO adm = new Adm2DTO();
                  adm.setId_adm(rs.getInt("id_adm"));
                  adm.setNome_adm(rs.getString("nome_adm"));
                  adm.setTelefone_adm(rs.getString("telefone_adm"));
                  adm.setEmail_adm(rs.getString("email_adm"));
                  
                  
                  //*irá armazenar o cargo dentro do vetor*/
                  Vector Vadm = new Vector();
                  Vadm.addElement(adm.getId_adm());
                  Vadm.addElement(adm.getNome_adm());
                  Vadm.addElement(adm.getTelefone_adm());
                  Vadm.addElement(adm.getEmail_adm());
                  
                  /*Adicionar o vetor de animais ao vetor principal */
                  lista.addElement(Vadm);
              }
              return lista;
          }catch(SQLException erro){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro ao listar:" +erro);
              return lista;
          }
      }
    
}
