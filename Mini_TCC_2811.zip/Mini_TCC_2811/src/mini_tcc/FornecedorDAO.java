
package mini_tcc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.Vector;

public class FornecedorDAO {
    Conexao conexao = new Conexao();
    public boolean cadastrar(FornecedorDTO fornecedor){
        
        String sql="Insert into tbfornecedor(id_fornec, nome_fornec, telefone_fornec, email_fornec, endereco_fornec, cnpj_fornec, produtofornecido)values (null,?,?,?,?,?,?)";
        try{
            PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
            psmt.setString(1,fornecedor.getNome_fornec());
            psmt.setString(2,fornecedor.getTelefone_fornec());
            psmt.setString(3,fornecedor.getEmail_fornec());
            psmt.setString(4,fornecedor.getEndereco_fornec());
            psmt.setString(5,fornecedor.getCnpj_fornec());
            psmt.setString(6,fornecedor.getProdutofornecido());
            //executeUpdate-criação,atualizacao e delete
            psmt.executeUpdate();
            return true;
          }catch(SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:"+ ex);
              return false;
          }
    }
    
    public FornecedorDTO Pesquisar (String cnpj){
          FornecedorDTO fornecedor = new FornecedorDTO();
          String sql = "Select id_fornec, cnpj_fornec, nome_fornec, email_fornec, telefone_fornec, endereco_fornec, produtofornecido from tbfornecedor where cnpj_fornec = ?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setString(1,cnpj);
              ResultSet rs = psmt.executeQuery();
              rs.next();
              fornecedor.setId_fornec(rs.getInt("id_fornec"));
              fornecedor.setCnpj_fornec(rs.getString("cnpj_fornec"));
              fornecedor.setNome_fornec(rs.getString("nome_fornec"));
              fornecedor.setEmail_fornec(rs.getString("email_fornec"));
              fornecedor.setTelefone_fornec(rs.getString("telefone_fornec"));
              fornecedor.setEndereco_fornec(rs.getString("endereco_fornec"));
              fornecedor.setProdutofornecido(rs.getString("produtofornecido"));
          }catch(SQLException e){
              JOptionPane.showMessageDialog(null,"Ocoreu um erro:"+e);
          }
          return fornecedor;
      }
    
    public boolean editar(FornecedorDTO fornecedor){
          String sql = "Update tbfornecedor set nome_fornec=?, telefone_fornec=?, email_fornec=?, endereco_fornec=?, cnpj_fornec=?, produtofornecido=? where id_fornec=?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setString(1,fornecedor.getNome_fornec());
              psmt.setString(2,fornecedor.getTelefone_fornec());
              psmt.setString(3,fornecedor.getEmail_fornec());
              psmt.setString(4,fornecedor.getEndereco_fornec());
              psmt.setString(5,fornecedor.getCnpj_fornec());
              psmt.setString(6,fornecedor.getProdutofornecido());
              psmt.setInt(7,fornecedor.getId_fornec());
              psmt.executeUpdate();//executeUpdate - criação,atualização e delete
          return true;
          }catch(SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:" +ex);
              return false;
          }
      }public boolean excluir(int id){
          String sql = "Delete from tbfornecedor where id_fornec = ?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setInt(1,id);
              psmt.executeUpdate();//executeUpdate - criação,atualização  e delete
              return true;
          }catch (SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:" +ex);
              return false;
          }
      }    
}
    

