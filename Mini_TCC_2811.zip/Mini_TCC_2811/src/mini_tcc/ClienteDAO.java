
package mini_tcc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

    public class ClienteDAO {
    
        Conexao conexao = new Conexao();
    public boolean cadastrar(ClienteDTO cliente){
        
        String sql="Insert into tbcliente(id_cliente,nome_cliente,telefone_cliente,email_cliente,data_nasc_cliente, endereco_cliente,cpf_cliente)values (null,?,?,?,?,?,?)";
        try{
            PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
            psmt.setString(1,cliente.getNome_cliente());
            psmt.setString(2,cliente.getTelefone_cliente());
            psmt.setString(3,cliente.getEmail_cliente());
            psmt.setString(4,cliente.getData_nasc_cliente());
            psmt.setString(5,cliente.getEndereco_cliente());
            psmt.setString(6,cliente.getCpf_cliente());
            //executeUpdate-criação,atualizacao e delete
            psmt.executeUpdate();
            return true;
          }catch(SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:"+ ex);
              return false;
          }
    }
    
    public ClienteDTO Pesquisar (String cpf){
          ClienteDTO cliente = new ClienteDTO();
          String sql = "Select id_cliente, nome_cliente, data_nasc_cliente, cpf_cliente, email_cliente, telefone_cliente, endereco_cliente from tbcliente where cpf_cliente = ?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setString(1,cpf);
              ResultSet rs = psmt.executeQuery();
              rs.next();
              cliente.setId_cliente(rs.getInt("id_cliente"));
              cliente.setNome_cliente(rs.getString("nome_cliente"));
              cliente.setData_nasc_cliente(rs.getString("data_nasc_cliente"));
              cliente.setCpf_cliente(rs.getString("cpf_cliente"));
              cliente.setEmail_cliente(rs.getString("email_cliente"));
              cliente.setTelefone_cliente(rs.getString("telefone_cliente"));
              cliente.setEndereco_cliente(rs.getString("endereco_cliente"));
          }catch(SQLException e){
              JOptionPane.showMessageDialog(null,"Ocoreu um erro:"+e);
          }
          return cliente;
      }
    
    public boolean editar(ClienteDTO cliente){
          String sql = "Update tbcliente set nome_cliente=?, data_nasc_cliente=?, cpf_cliente=?, email_cliente=?, telefone_cliente=?, endereco_cliente=? where id_cliente=?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setString(1,cliente.getNome_cliente());
              psmt.setString(2,cliente.getData_nasc_cliente());
              psmt.setString(3,cliente.getCpf_cliente());
              psmt.setString(4,cliente.getEmail_cliente());
              psmt.setString(5,cliente.getTelefone_cliente());
              psmt.setString(6,cliente.getEndereco_cliente());
              psmt.setInt(7,cliente.getId_cliente());
              psmt.executeUpdate();//executeUpdate - criação,atualização e delete
          return true;
          }catch(SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:" +ex);
              return false;
          }
    }
          public boolean excluir(int id){
          String sql = "Delete from tbcliente where id_cliente = ?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setInt(1,id);
              psmt.executeUpdate();//executeUpdate - criação,atualização  e delete
              return true;
          }catch (SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:" +ex);
              return false;
          }
   }
    
 }  
     


