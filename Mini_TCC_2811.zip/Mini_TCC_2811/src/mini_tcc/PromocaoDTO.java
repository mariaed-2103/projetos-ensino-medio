
package mini_tcc;

public class PromocaoDTO {
    
      private int id_promo;
    private String marca_promo;
    private String duracao ;
    private Double valor;
    private String categoria;
    private Double desconto;
    private Double valorpromo;

    public Double getValorpromo() {
        return valorpromo;
    }

    public void setValorpromo(Double valorpromo) {
        this.valorpromo = valorpromo;
    }

    public int getId_promo() {
        return id_promo;
    }

    public void setId_promo(int id_promo) {
        this.id_promo = id_promo;
    }

    public String getMarca_promo() {
        return marca_promo;
    }

    public void setMarca_promo(String marca_promo) {
        this.marca_promo = marca_promo;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Double getDesconto() {
        return desconto;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }
    

}
