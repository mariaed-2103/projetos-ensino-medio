
package mini_tcc;

public class AdmDTO {

    public int getId_adm() {
        return id_adm;
    }

    public void setId_adm(int id_adm) {
        this.id_adm = id_adm;
    }

    public String getNome_adm() {
        return nome_adm;
    }

    public void setNome_adm(String nome_adm) {
        this.nome_adm = nome_adm;
    }

    public String getTelefone_adm() {
        return telefone_adm;
    }

    public void setTelefone_adm(String telefone_adm) {
        this.telefone_adm = telefone_adm;
    }

    public String getEmail_adm() {
        return email_adm;
    }

    public void setEmail_adm(String email_adm) {
        this.email_adm = email_adm;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getDatanasc_adm() {
        return datanasc_adm;
    }

    public void setDatanasc_adm(String datanasc_adm) {
        this.datanasc_adm = datanasc_adm;
    }

    private int id_adm;
    private String nome_adm;
    private String telefone_adm;
    private String email_adm;
    private String cargo;
    private String datanasc_adm;
}
