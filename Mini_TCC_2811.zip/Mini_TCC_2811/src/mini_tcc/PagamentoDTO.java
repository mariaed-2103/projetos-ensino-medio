
package mini_tcc;

public class PagamentoDTO {
    
    private double sabor,tamanho,total;
    private boolean entrega,borda;

    public double getSabor() {
        return sabor;
    }

    public void setSabor(double sabor) {
        this.sabor = sabor;
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public boolean isEntrega() {
        return entrega;
    }

    public void setEntrega(boolean entrega) {
        this.entrega = entrega;
    }

    public boolean isBorda() {
        return borda;
    }

    public void setBorda(boolean borda) {
        this.borda = borda;
    }
    
}
