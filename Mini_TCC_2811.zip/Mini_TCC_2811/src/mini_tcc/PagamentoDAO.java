
package mini_tcc;

public class PagamentoDAO {
    
    public double CalcularTotal(PagamentoDTO objPizza){
        objPizza.setTotal(objPizza.getSabor()*objPizza.getTamanho());
        if(objPizza.isBorda()){
            objPizza.setTotal(objPizza.getTotal()+5);
        }
        if(objPizza.isEntrega()){
            objPizza.setTotal(objPizza.getTotal()+3);
        }
       
        return objPizza.getTotal();
    }
    
}
