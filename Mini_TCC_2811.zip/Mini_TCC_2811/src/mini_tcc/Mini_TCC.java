package mini_tcc;

import javax.swing.JFrame;

public class Mini_TCC {

    public static void main(String[] args) {
        frmPrincipal form = new frmPrincipal();
        form.setVisible(true);
        form.setExtendedState(form.getExtendedState() | JFrame.MAXIMIZED_BOTH);
    }
    
}