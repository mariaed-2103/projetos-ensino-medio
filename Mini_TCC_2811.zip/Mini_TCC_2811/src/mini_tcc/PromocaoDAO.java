
package mini_tcc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.Vector;

public class PromocaoDAO {
    
    Conexao conexao = new Conexao();
    public boolean cadastrar(PromocaoDTO promocao){
        
        String sql="Insert into tbproduto_promocao(id_promo, marca_promo, duracao, categoria, valor, desconto)values (null,?,?,?,?,?)";
        try{
            PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
            psmt.setString(1,promocao.getMarca_promo());
            psmt.setString(2,promocao.getDuracao());
            psmt.setString(3,promocao.getCategoria());
            psmt.setDouble(4,promocao.getValor());
            psmt.setDouble(5,promocao.getDesconto());
            //executeUpdate-criação,atualizacao e delete
            psmt.executeUpdate();
            return true;
          }catch(SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:"+ ex);
              return false;
          }
    
    }
    public PromocaoDTO Pesquisar (int id){
          PromocaoDTO promocao = new PromocaoDTO();
          String sql = "Select id_promo, marca_promo, duracao, categoria, valor, desconto from tbpromocao where id_promo = ?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setInt(1,id);
              ResultSet rs = psmt.executeQuery();
              rs.next();
              promocao.setId_promo(rs.getInt("id_promo"));
              promocao.setMarca_promo(rs.getString("marca_promo"));
              promocao.setDuracao(rs.getString("duracao"));
              promocao.setCategoria(rs.getString("categoria"));
              promocao.setValor(rs.getDouble("valor"));
              promocao.setDesconto(rs.getDouble("desconto"));
          }catch(SQLException e){
              JOptionPane.showMessageDialog(null,"Ocoreu um erro:"+e);
          }
          return promocao;
      }
    public boolean editar(PromocaoDTO promocao){
          String sql = "Update tbproduto_promocao set marca_promo=?, duracao=?, categoria=?, valor=?, desconto=? where id_promo=?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setString(1,promocao.getMarca_promo());
              psmt.setString(2,promocao.getDuracao());
              psmt.setString(3,promocao.getCategoria());
              psmt.setDouble(4,promocao.getValor());
              psmt.setDouble(5,promocao.getDesconto());
              psmt.setInt(6,promocao.getId_promo());
              psmt.executeUpdate();//executeUpdate - criação,atualização e delete
          return true;
          }catch(SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:" +ex);
              return false;
          }
    }
    public boolean excluir(int id){
          String sql = "Delete from tbpet where id_promo = ?";
          try{
              PreparedStatement psmt = conexao.conectar().prepareStatement(sql);
              psmt.setInt(1,id);
              psmt.executeUpdate();//executeUpdate - criação,atualização  e delete
              return true;
          }catch (SQLException ex){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro:" +ex);
              return false;
          }
      }
    public Vector Listar(){
          Vector lista = new Vector();
          try{
              String SQL = "Select id_promo, ,marca_promo, categoria, duracao, valor, desconto from tbproduto_promocao";
              PreparedStatement psmt = conexao.conectar().prepareStatement(SQL);
              ResultSet rs = psmt.executeQuery();
              
              while(rs.next()){
                  PromocaoDTO promocao = new PromocaoDTO();
                  promocao.setId_promo(rs.getInt("id_promo"));
                  promocao.setMarca_promo(rs.getString("marca_promo"));
                  promocao.setCategoria(rs.getString("categoria"));
                  promocao.setDuracao(rs.getString("duracao"));
                  promocao.setValor(rs.getDouble("valor"));
                  promocao.setDesconto(rs.getDouble("desconto"));
                  
                  
                  //*irá armazenar o animal dentro do vetor*/
                  Vector Vpromocao = new Vector();
                  Vpromocao.addElement(promocao.getId_promo());
                  Vpromocao.addElement(promocao.getMarca_promo());
                  Vpromocao.addElement(promocao.getCategoria());
                  Vpromocao.addElement(promocao.getDuracao());
                  Vpromocao.addElement(promocao.getValor());
                  Vpromocao.addElement(promocao.getDesconto());
                  
                  /*Adicionar o vetor de animais ao vetor principal */
                  lista.addElement(Vpromocao);
              }
              return lista;
          }catch(SQLException erro){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro ao listar:" +erro);
              return lista;
          }
      }
    public Vector Listar(String Categoria){
          Vector lista = new Vector();
          try{
              String SQL = "Select id_promo, marca_promo, categoria, duracao, valor, desconto from tbproduto_promocao where categoria=?";
              PreparedStatement psmt = conexao.conectar().prepareStatement(SQL);
              psmt.setString(1,Categoria);
              ResultSet rs = psmt.executeQuery();
              
              while(rs.next()){
                  PromocaoDTO promocao = new PromocaoDTO();
                  promocao.setId_promo(rs.getInt("id_promo"));
                  promocao.setMarca_promo(rs.getString("marca_promo"));
                  promocao.setCategoria(rs.getString("categoria"));
                  promocao.setDuracao(rs.getString("duracao"));
                  promocao.setValor(rs.getDouble("valor"));
                  promocao.setDesconto(rs.getDouble("desconto"));
                  
                  //*irá armazenar o animal dentro do vetor*/
                  Vector Vpromocao = new Vector();
                  Vpromocao.addElement(promocao.getId_promo());
                  Vpromocao.addElement(promocao.getMarca_promo());
                  Vpromocao.addElement(promocao.getCategoria());
                  Vpromocao.addElement(promocao.getDuracao());
                  Vpromocao.addElement(promocao.getValor());
                  Vpromocao.addElement(promocao.getDesconto());
                  
                  /*Adicionar o vetor de animais ao vetor principal */
                  lista.addElement(Vpromocao);
              }
              return lista;
          }catch(SQLException erro){
              JOptionPane.showMessageDialog(null,"Ocorreu um erro ao listar:" +erro);
              return lista;
          }
      }
    
}
